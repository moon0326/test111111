<?php

defined( 'ABSPATH' ) || exit;

$redirectors = get_option( WCA_Test_Helper_Remote_Get_Redirector::OPTION_NAME, array() );

add_filter(
	'pre_http_request',
	function ( $preempt, $parsed_args, $url ) use ( $redirectors ) {
		$logger = new WC_Logger();
		$log_entry = "URL: $url\n";

		foreach ( $redirectors as $redirector ) {
			if ( $url === $redirector['original_endpoint'] ) {
				if ( empty( $redirector['enabled'] ) ) {
					continue;
				}

				if ( ! empty( $redirector['username'] ) && ! empty( $redirector['password'] ) ) {
					$parsed_args['headers']['Authorization'] = 'Basic ' . base64_encode( $redirector['username'] . ':' . $redirector['password'] );
				}
				$response =  wp_remote_get( $redirector['new_endpoint'], $parsed_args );
				$log_entry .= print_r( $response, true );
			}
		}
		$logger->add('wp_remote_get_logger', $log_entry);
		return false;
	},
	10,
	3
);