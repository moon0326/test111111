export const STORE_KEY = 'wc-admin-helper/experiments';
export const EXPERIMENT_NAME_PREFIX = 'explat-experiment--';
export const TRANSIENT_NAME_PREFIX = '_transient_abtest_variation_';
export const TRANSIENT_TIMEOUT_NAME_PREFIX =
	'_transient_timeout_abtest_variation';
export const API_NAMESPACE = '/wc-admin-test-helper';
