export function getFeatures( state ) {
	return state.features;
}

export function getModifiedFeatures( state ) {
	return state.modifiedFeatures;
}
