export const STORE_KEY = 'wc-admin-helper/options';
export const API_NAMESPACE = '/wc-admin-test-helper';
