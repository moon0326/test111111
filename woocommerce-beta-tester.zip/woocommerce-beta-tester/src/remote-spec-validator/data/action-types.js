const TYPES = {
	VALIDATE: 'VALIDATE',
	SET_MESSAGE: 'SET_MESSAGE',
};

export default TYPES;
