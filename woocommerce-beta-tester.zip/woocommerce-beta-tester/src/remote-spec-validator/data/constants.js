export const STORE_KEY = 'wc-admin-helper/remote-spec-validator';
export const API_NAMESPACE = '/wc-admin-test-helper';
