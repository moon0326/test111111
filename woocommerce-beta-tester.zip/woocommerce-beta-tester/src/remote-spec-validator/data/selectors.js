export function getMessage( state ) {
	return state.message;
}
