export const STORE_KEY = 'wc-admin-helper/request-redirects';
export const API_NAMESPACE = '/wc-admin-test-helper';

// Option name where we're going to save the redirectors.
export const FILTERS_OPTION_NAME = 'wc-admin-test-helper-request-redirects';
