export function getRedirectors( state ) {
	return state.redirectors;
}

export function isLoading( state ) {
	return state.isLoading;
}
