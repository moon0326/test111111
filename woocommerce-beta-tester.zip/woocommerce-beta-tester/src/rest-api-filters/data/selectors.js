export function getFilters( state ) {
	return state.filters;
}

export function isLoading( state ) {
	return state.isLoading;
}
