export const STORE_KEY = 'wc-admin-helper/tools';
export const API_NAMESPACE = '/wc-admin-test-helper';
