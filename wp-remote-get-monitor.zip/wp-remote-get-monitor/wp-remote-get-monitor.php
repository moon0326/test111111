<?php
/*
Plugin Name: WP Remote Get Logger
Description: Logs wp_remote_get requests to the WooCommerce log.
Version: 1.0
Author: Your Name
*/

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Hook into the 'http_api_debug' action to log wp_remote_get requests
add_action('pre_http_request', 'log_wp_remote_get_requests', 10, 3);

function log_wp_remote_get_requests($preempt, $parsed_args, $url) {

    $logger = new WC_Logger();
    // Log details about the request
    $log_entry = "URL: " . esc_url($url);

    // Add the log entry
    $logger->add('wp_remote_get_logger', $log_entry);
}

